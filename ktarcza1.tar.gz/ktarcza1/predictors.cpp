#include "predictors.h"

using namespace std;
std::vector<std::string> branches;

void readInStuff(char* filename){
	string line;
	ifstream myfile(filename);
	if(myfile.is_open()){
		while(getline(myfile,line)){
			branches.push_back(line);
		}
		myfile.close();
		//printf("File Read In\n");
	}
	else
		cout <<"Unable to open " << filename <<endl;
}

int alwaysTaken(){
	int correct = 0;
	for(int i=0;i<branches.size();i++){
		if(branches.at(i).length()==12)
			correct++;
	}
	return correct;
}

int alwaysNonTaken(){
	int correct = 0;
	for(int i=0;i<branches.size();i++)
		if(branches.at(i).length()==13)
			correct++;
	return correct;
}

int stringToIndex(int index, int size){
	//isolate address
	string temp = branches.at(index).substr(2,9);
	//turn into binary
	std::stringstream ss;
	ss<<std::hex<<temp;
	unsigned int x;
	ss>>x;
	//cout<<temp << " = " << x <<endl;
	return x%size;
}

int bimodal(int size){
	int table [size];
	for(int i=0;i<size;i++)
		table[i] = 1;
	int index;
	int guess;
	int correct = 0;
	for(int i=0;i<branches.size();i++){
		index = stringToIndex(i,size);
		guess = table[index];
		if(branches.at(i).length()==12){
			if(guess==1)
				correct++;
			table[index] = 1;
		}
		else if(branches.at(i).length()==13){
			if(guess==0)
				correct++;
			table[index] = 0;
		}
	}
	return correct;
}

int bimodalS(int size){
	int table [size];
	for(int i=0;i<size;i++)
		table[i] = 3;
	int index;
	int guess;
	int correct = 0;
	for(int i=0;i<branches.size();i++){
		index = stringToIndex(i,size);
		guess = table[index];
		if(branches.at(i).length()==12){
			//0 SNT, 1 WNT, 2 WT, 3 ST			
			if(guess > 1){
				correct++;
			}
			if(table[index] != 3)
				table[index]++;
		}
		else if(branches.at(i).length()==13){
			if(guess < 2)
				correct++;
			if(table[index]!=0)
				table[index]--;
		}
	}
	return correct;
}

int stringToIndexGshare(int i, unsigned int history, int hL){
	string temp = branches.at(i).substr(2,9);
	std::stringstream ss;
	ss<<std::hex<<temp;
	unsigned int x = 0;
	ss>>x;	//unsigned integer
	unsigned int max = 4294967295;
	// all 1s =  4294967295
	//shift right to match number of bits in history
	//and full history with ^ to create history with correct number of bits
	//XOR ^ with the PC
	return (((max>>(32-hL)) & history)^x)%2048;
}

int gshare(int historyLength){
	int table [2048];
	//initializing table
	for(int i=0;i<2048;i++){
		table[i]=3;
	}
	unsigned int history = 0;
	int index = 0;
	int guess = 0;
	int correct = 0;
	for(int i=0;i<branches.size();i++){
		index = stringToIndexGshare(i,history,historyLength);	
		guess = table[index];
		history<<1;
		if(branches.at(i).length()==12){
			//0 SNT, 1 WNT, 2 WT, 3 ST			
			if(guess > 1){
				correct++;
			}
			if(table[index] < 3)
				table[index]++;
			history++;
		}
		else if(branches.at(i).length()==13){
			if(guess < 2)
				correct++;
			if(table[index]>0)
				table[index]--;
		}		
	}
	return correct;
}

int tournament(){
	//0 GG, 1 G, 2 B, 3 BB	
	int ttable [2048];
	int btable [2048];
	int gtable [2048];
	for(int i=0;i<2048;i++){
		ttable[i] = 0;
		btable[i] = 3;
		gtable[i]=3;
	}

	int index = 0;
	int bindex = 0;
	int gindex = 0;
	int preChoice = 0;
	int correct = 0;
	unsigned int history = 0;
	bool bguess = false;
	bool gguess = false;

	for(int i=0;i<branches.size();i++){
		index = stringToIndex(i,2048);
		preChoice = ttable[index];

		//get values for each
		bguess = btable[index];	
		gguess = gtable[stringToIndexGshare(i,history,11)];

		//choose the option inicated
		if(preChoice > 1){
			if(branches.at(i).length()==12){
				//0 SNT, 1 WNT, 2 WT, 3 ST			
				if(bguess > 1){
					correct++;
					if(ttable[index] != 3)
						ttable[index]++;
				}
				else
					if(ttable[index] != 0)
						ttable[index]--;
				if(btable[index] != 3)
					btable[index]++;
			}
			else if(branches.at(i).length()==13){
				if(bguess < 2){
					correct++;
					if(ttable[index]!=3)
						ttable[index]++;
				}
				else
					if(ttable[index]!=0)
						ttable[index]--;
				if(btable[index]!=0)
					btable[index]--;
			}
			//do bimodal
			//if prediction correct, move toward 3
			//if incorrect, decrement		
		}
		else{
			history<<1;
			if(branches.at(i).length()==12){
				//0 SNT, 1 WNT, 2 WT, 3 ST			
				history++;
				if(gguess > 1){
					correct++;
					if(ttable[index] != 3)
						ttable[index]++;
				}
				else
					if(ttable[index] != 0)
						ttable[index]--;
				if(gtable[index] != 3)
					gtable[index]++;
			}
			else if(branches.at(i).length()==13){
				if(gguess < 2){
					correct++;
					if(ttable[index]!=3)
						ttable[index]++;
				}
				else
					if(ttable[index]!=0)
						ttable[index]--;
				if(gtable[index]!=0)
					gtable[index]--;
			}
			//do gshare
			//if prediction correct, move toward 0
			//if incorrect, increment
		}
	}
	return correct;
}


int main(int argc, char* argv[]){
	//printf("Hello world\n");
	readInStuff(argv[1]);
	//readInStuff("short_trace1.txt");

	ofstream myfile (argv[2]);
	if (myfile.is_open())
	{
		myfile << alwaysTaken() << "," << branches.size() <<";\n";
		myfile << alwaysNonTaken() << "," << branches.size() <<";\n";

		myfile << bimodal(16) << "," << branches.size() <<"; ";
		myfile << bimodal(32) << "," << branches.size() <<"; ";
		myfile << bimodal(128) << "," << branches.size() <<"; ";
		myfile << bimodal(256) << "," << branches.size() <<"; ";
		myfile << bimodal(512) << "," << branches.size() <<"; ";
		myfile << bimodal(1024) << "," << branches.size() <<"; ";
		myfile << bimodal(2048) << "," << branches.size() <<";\n";

		myfile << bimodalS(16) << "," << branches.size() <<"; ";
		myfile << bimodalS(32) << "," << branches.size() <<"; ";
		myfile << bimodalS(128) << "," << branches.size() <<"; ";
		myfile << bimodalS(256) << "," << branches.size() <<"; ";
		myfile << bimodalS(512) << "," << branches.size() <<"; ";
		myfile << bimodalS(1024) << "," << branches.size() <<"; ";
		myfile << bimodalS(2048) << "," << branches.size() <<";\n";

		for(int i=3;i<12;i++)
			myfile << gshare(i) << "," << branches.size() <<"; ";
		myfile <<"\n";
		
		myfile << tournament() << "," << branches.size() <<";";
	}
	return 0;
}
