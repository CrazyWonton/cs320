#ifndef PREDICTORS_H
#define PREDICTORS_H
#include <stdio.h>
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
class predictors{

	public:
		void readInStuff(char* filename);
		int alwaysTaken();
		int alwaysNonTaken();
		int bimodal(int size);
		int bimodalS(int size);
		int gshare(int size);
		int tournament();
		//std::list<long> addresses;
		//std::vector<bool> branches;


};

#endif
